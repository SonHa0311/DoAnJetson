This is the Arduino Code which controls the car based on the instructions received from Jetson Nano.
