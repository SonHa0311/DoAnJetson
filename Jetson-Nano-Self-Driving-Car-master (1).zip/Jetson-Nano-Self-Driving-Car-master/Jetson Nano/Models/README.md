This is the folder where the trained TF Lite model should be pasted in Jetson Nano.
