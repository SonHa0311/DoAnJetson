This is the folder where RECORD.py will store the Images.
