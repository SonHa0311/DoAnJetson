All the .npy datasets files will be saved into this folder by DATA.py
