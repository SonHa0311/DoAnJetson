This is the folder where the TF Lite models will be saved by CONVERT.PY
