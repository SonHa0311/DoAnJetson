This is the folder where CONVERT.py will save the hdf5 model as .model file
