This is the folder where MODEL.py will checkpoint the model while training the steer angle prediction model.
