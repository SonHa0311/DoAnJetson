This is the folder where MODEL.py will save the models to predict the direction to move in using classification.
