All the Images must be copied into this folder.
